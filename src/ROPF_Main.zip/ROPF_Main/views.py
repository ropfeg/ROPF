from django.http import HttpResponse
from django.shortcuts import render


def home_page(request):
    return render(request, "login.html" , {})

def under_construction(request):
    user_name = request.user.username

    context = {"username": user_name, "user_region": "None"}
    return render(request,"under_construction.html",context)

